package com.example.soufianebenchraa.appdouleur.View;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.soufianebenchraa.appdouleur.R;

public class Patient extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}
