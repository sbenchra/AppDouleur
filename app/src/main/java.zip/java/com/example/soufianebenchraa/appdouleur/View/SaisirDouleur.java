package com.example.soufianebenchraa.appdouleur.View;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.example.soufianebenchraa.appdouleur.Model.Douleur;
import com.example.soufianebenchraa.appdouleur.Model.DouleurDAO;
import com.example.soufianebenchraa.appdouleur.Model.Patient;
import com.example.soufianebenchraa.appdouleur.R;
import com.example.soufianebenchraa.appdouleur.utils.EditModalPatient;
import com.example.soufianebenchraa.appdouleur.utils.ModalDouleur;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class SaisirDouleur extends AppCompatActivity implements Serializable {
    Patient patient;
    ModalDouleur editNameDialogFragment;
    ImageView image;
    Douleur douleur;
    DouleurDAO douleurdao;
    String partieCorps="";
    @SuppressLint("ClickableViewAccessibility")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.douleurhomme);
        Intent intent = getIntent();
        image = (ImageView) this.findViewById(R.id.imageView);
      //  patient = (Patient) intent.getSerializableExtra("patient");

        image.setOnTouchListener(new View.OnTouchListener() {

            @Override

            public boolean onTouch(View v, MotionEvent event) {


                int x = (int) event.getX();
                int y = (int) event.getY();

                if((x==276 && y==20) ){
                    onCreateContextMenu();

                    partieCorps="C1";
                    Log.d("Click", "C1");
                }
                else if((x==296 && y==70) ){
                    onCreateContextMenu();

                    Log.d("Click", "C2");
                }
                else if ((x==219 && y==60) || (x==269 && y==58) ){
                    onCreateContextMenu();
                    partieCorps="C3";
                }
                else if((x==255 && y==85) ){
                    onCreateContextMenu();
                    partieCorps="C4";
                }
                else if((x==199 && y==111) || (x==315 && y==112)){
                    onCreateContextMenu();
                    partieCorps="C5";
                }
                else if((x==182 && y==173) || (x==331 && y==117)){
                    onCreateContextMenu();
                    partieCorps="C6";
                }
                else if((x==151 && y==256) || (x==362 && y==258)){
                    onCreateContextMenu();
                    partieCorps="C7";
                }
                else if((x==167 && y==230) || (x==344 && y==233)){
                    onCreateContextMenu();
                    partieCorps="C7";
                }

                else if((x==195 && y==180) || (x==318 && y==178)){
                    onCreateContextMenu();
                    partieCorps="TH1";
                }
                else if((x==254 && y==107) ){
                    onCreateContextMenu();
                    partieCorps="TH2";

                }
                else if((x==254 && y==117) ){
                    onCreateContextMenu();
                    partieCorps="TH3";

                }
                else if((x==254 && y==127) ){
                    onCreateContextMenu();
                    partieCorps="TH4";

                }
                else if((x==254 && y==127) ){
                    onCreateContextMenu();
                    partieCorps="TH5";

                }
                else if((x==254 && y==163) ){
                    onCreateContextMenu();
                    partieCorps="TH6";

                }
                else if((x==254 && y==173) ){
                    onCreateContextMenu();
                    partieCorps="TH7";

                }
                else if((x==254 && y==184) ){
                    onCreateContextMenu();
                    partieCorps="TH8";

                }
                else if((x==254 && y==193) ){
                    onCreateContextMenu();
                    partieCorps="TH9";
                }
                else if((x==254 && y==202) ){
                    onCreateContextMenu();
                    partieCorps="TH10";
                }
                else if((x==254 && y==214) ){
                    onCreateContextMenu();
                    partieCorps="TH11";
                }
                else if((x==254 && y==229) ){
                    onCreateContextMenu();
                    partieCorps="TH12";
                }
                else if((x==254 && y==246) ){
                    onCreateContextMenu();
                    partieCorps="L1";
                }
                else if((x==211 && y==280) || (x==298 && y==280)){
                    onCreateContextMenu();
                    partieCorps="L2";
                }
                else if((x==235 && y==280) || (x==275 && y==280)){

                    onCreateContextMenu();
                    partieCorps="L3";
                }
                else if((x==239 && y==406) || (x==273 && y==406)){
                    onCreateContextMenu();
                    partieCorps="L4";
                }
                else if((x==223 && y==388) || (x==290 && y==389)){
                    partieCorps="L5";
                }
                else if((x==222 && y==431) || (x==290 && y==431)){
                    partieCorps="S1";
                }


                return true;

            }

        });

    }
/*
    public String getCurrentTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss");
        String strDate = mdformat.format(calendar.getTime());

        return strDate;
    }
    public void un(View un){

         douleur =new Douleur(getCurrentTime(),partieCorps, 1,patient);
        douleurdao.ajouterDouleur(douleur);

    }
    public void deux(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 2,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void trois(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 3,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void quatre(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 4,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void cinq(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 5,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void six(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 6,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void sept(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 7,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void huit(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 8,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void neuf(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 9,patient);
        douleurdao.ajouterDouleur(douleur);
    }
    public void dix(View un){
        douleur =new Douleur(getCurrentTime(),partieCorps, 10,patient);
        douleurdao.ajouterDouleur(douleur);
    }

*/

    public void onCreateContextMenu()
    {
        FragmentManager fm = getSupportFragmentManager();
        editNameDialogFragment = ModalDouleur.newInstance("soufiane");
        editNameDialogFragment.show(fm, "fragment_edit_name");

    }


}