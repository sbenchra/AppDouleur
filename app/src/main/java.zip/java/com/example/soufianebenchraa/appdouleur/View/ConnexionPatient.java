package com.example.soufianebenchraa.appdouleur.View;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.soufianebenchraa.appdouleur.Model.Patient;
import com.example.soufianebenchraa.appdouleur.Model.PatientDAO;
import com.example.soufianebenchraa.appdouleur.R;

public class ConnexionPatient extends AppCompatActivity {

    PatientDAO patientDAO;
    EditText tonEdit;
    EditText tonEdit1;
    String pseudo;
    String motdepasse;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connexionpatient);



    }

    public void connect(View connexion){

        tonEdit = (EditText) findViewById(R.id.editText3);
        pseudo = tonEdit.getText().toString();
        tonEdit1 = (EditText) findViewById(R.id.editText7);
        motdepasse = tonEdit1.getText().toString();
        long exist = patientDAO.CheckPatient(pseudo, motdepasse);
        if (exist != 1) {
            Intent i = new Intent(ConnexionPatient.this, SaisirDouleur.class);
            Patient p= patientDAO.getPatient(pseudo);
            i.putExtra("Patient",p);
            startActivity(i);
        } else {
            //TODO il faut afficher une erreur au utilisateur
            Log.e("Connexion", "Une erreur est survenue lors de la connexion");
        }
        if (patientDAO.CheckPossiblity(pseudo)==0)
        {
            Toast.makeText(getApplicationContext(),"Votre compte n'a pas encore été vérfié",Toast.LENGTH_LONG).show();
        }
    }
}
