package com.example.soufianebenchraa.appdouleur.Model;

import java.io.Serializable;

public class Ail implements Serializable {

    private String Ail;


    public Ail(String ail) {
        Ail = ail;
    }

    public String getAil() {
        return Ail;
    }

    public void setAil(String ail) {
        Ail = ail;
    }
}
